---
title: GPU resources
description: Using available GPU resources on the cluster
published: true
date: 2024-05-02T13:19:09.089Z
tags: gpu
editor: markdown
dateCreated: 2023-03-15T12:14:31.689Z
---

# GPU resources on the cluster

The BMRC cluster includes a number of NVidia GPU-accelerated nodes which are accessible through queueing system's commands.  

If you would like to submit jobs to these GPU nodes, please get in touch with KIR Research Computing Administrator.

## Available GPU nodes

Because of rapidly changing hardware capabilities, there is considerable variation in the hardware  of the GPU nodes: they offer different combinations of CPU and RAM as well as different types of GPU card. Furthermore, each node is configured to host only as many slots as it has GPU cards, on the assumption that every job will need at least one GPU card. As a consequence, the RAM and number of CPUs allocated per slot on the GPU queue can vary as indicated in the table below. 

Because of the variation in CPU, RAM, GPU card type available per node, you may need to plan your job submissions carefully. The sections below provide full information on the nodes available in order to assist with your planning.

## Submitting a job to GPU nodes

There are 21 GPU nodes which are available through the scheduler.

There are 3 cluster partitions for GPU resources, `gpu_short`, `gpu_long` for general batch jobs and `gpu_interactive` intended for interactive jobs.

> `gpu_interactive` partition is available on two nodes (compg009 and compg010) which feature P100 16GB GPU cards and are particularly suitable for interactive code development and other interactive jobs run through srun command.
{.is-info}

Jobs run on `gpu_interactive` have a maximum duration of 12 hours.

Jobs run on `gpu_short` have a maximum duration of 4 hours.

Jobs run on `gpu_long` have a maximum duration of 60 hours.

> `gpu_long` partition is only available on a subset of GPU nodes, so it is recommended that you use `gpu_short` partition whenever possible.
{.is-info}

Jobs can be submitted to `gpu_short` or `gpu_long` partitions using `sbatch` command in a similar way to submitting a non-gpu job, for example:
```
sbatch -p gpu_short --gres gpu:N your_script.sh
``` 
or 
```
sbatch -p gpu_short --gpus-per-node N your_script.sh
```
`N` is the number of GPUs required for your job. Note the maximum number of GPU cards available per node is 4 as shown in the table below.

You can specify a particular type of GPU in the following way: 

```
sbatch -p gpu_short --gres gpu:a100-pcie-40gb:2 your_script.sh
```
The example above requests 2 GPU of a100-pcie-40gb type. The available GPU types are listed in the table below. 

When submitting jobs, the total RAM achievable for your job will be `RAM per slot x N slots`. The default RAM is 60 GB per slot, so the example command above will have requested 120 GB of RAM. 

<table>
	<tr>
    <td><b>Node</b></td>
    <td><b>GPU Type</b></td>
    <td><b>Num GPU Cards</b></td>
    <td><b>GPU RAM per card/GB</b></td>
    <td><b>CPU cores per Slot</b></td>
    <td><b>RAM per slot/GB</b></td>
    <td><b>CPU compatibility</b></td>
  </tr>
 <tr>
		<td>compg009</td>
		<td>p100-sxm2-16gb</td>
		<td>4</td>
		<td>16</td>
 		<td>6</td>
		<td>91</td>
		<td>Skylake</td>
  </tr>
	<tr>
		<td>compg010</td>
		<td>p100-sxm2-16gb</td>
		<td>4</td>
		<td>16</td>
		<td>6</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg011</td>
		<td>p100-sxm2-16gb</td>
		<td>4</td>
		<td>16</td>
		<td>6</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg013</td>
		<td>p100-sxm2-16gb</td>
		<td>4</td>
		<td>16</td>
		<td>6</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
  	<tr>
		<td>compg016</td>
		<td>v100-pcie-32gb</td>
		<td>2</td>
		<td>32</td>
		<td>6</td>
		<td>750</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg026</td>
		<td>p100-pcie-16gb</td>
		<td>4</td>
		<td>16</td>
		<td>10</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg027</td>
		<td>v100-pcie-16gb</td>
		<td>4</td>
		<td>16</td>
		<td>12</td>
		<td>60</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg028</td>
		<td>quadro-rtx8000</td>
		<td>4</td>
		<td>48</td>
		<td>8</td>
		<td>187</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg029</td>
		<td>quadro-rtx8000</td>
		<td>4</td>
		<td>48</td>
		<td>8</td>
		<td>187</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg030</td>
		<td>quadro-rtx8000</td>
		<td>4</td>
		<td>48</td>
		<td>8</td>
		<td>187</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg031</td>
		<td>a100-pcie-40gb</td>
		<td>4</td>
		<td>40</td>
		<td>8</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg032</td>
		<td>a100-pcie-40gb</td>
		<td>4</td>
		<td>40</td>
		<td>8</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg033</td>
		<td>a100-pcie-40gb</td>
		<td>4</td>
		<td>40</td>
		<td>8</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg034</td>
		<td>a100-pcie-40gb</td>
		<td>4</td>
		<td>40</td>
		<td>8</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg035</td>
		<td>a100-pcie-80gb</td>
		<td>4</td>
		<td>80</td>
		<td>8</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg036</td>
		<td>a100-pcie-80gb</td>
		<td>4</td>
		<td>80</td>
		<td>8</td>
		<td>91</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg037</td>
		<td>a100-pcie-80gb</td>
		<td>2</td>
		<td>80</td>
		<td>24</td>
		<td>256</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg038</td>
		<td>a100-pcie-80gb</td>
		<td>2</td>
		<td>80</td>
		<td>24</td>
		<td>256</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg039</td>
		<td>a100-pcie-80gb</td>
		<td>4</td>
		<td>80</td>
		<td>12</td>
		<td>128</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg040</td>
		<td>a100-pcie-80gb</td>
		<td>4</td>
		<td>80</td>
		<td>12</td>
		<td>128</td>
		<td>Skylake</td>
	</tr>
	<tr>
		<td>compg041</td>
		<td>a100-pcie-80gb</td>
		<td>4</td>
		<td>80</td>
		<td>12</td>
		<td>128</td>
		<td>Skylake</td>
	</tr>
</table>

The default number of CPU cores allocated per GPU is shown in CPU cores per Slot. You can request more (or fewer) CPU cores for your job with `--cpus-per-gpu N` option. Alternatively, you can set the total number of cores required for the job with `-c N` option, where `N` is the number of required cores.

The default system memory available per GPU is 60 GB per Slot. You can request more (or less) system memory for your job with `--mem-per-gpu MG` option up to the `RAM per slot x N slots` limit. Alternatively, you can specify the total memory requirement for your job with `--mem MG`, where `M` is the memory required in GB.

## Interactive GPU sessions

The recommended way to request an interactive session is through `srun` command using the `gpu_interactive` partition:

```
srun -p gpu_interactive --gres gpu:1 --pty bash
``` 

It is also possible to request an interactive session on the scheduled GPU nodes on other partitions with `srun` command. For example:

```
srun -p gpu_short --gres gpu:1 --pty bash
``` 

You can use the `nvidia-smi` command to check what processes are running on the GPUs and `top` command to check what is running on the CPUs when logged in onto a GPU node.

## Job monitoring

To check the status of all jobs submitted to all GPU partitions, run:
```
 squeue -p gpu_short,gpu_long,gpu_interactive
```
from the cluster login node.

